package com.javarush.task.task18.task1828;

/* 
Прайсы 2
*/

public class Solution {
    public static void main(String[] args) {

    }
}
