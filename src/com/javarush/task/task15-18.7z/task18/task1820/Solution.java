package com.javarush.task.task18.task1820;

/* 
Округление чисел
*/

public class Solution {
    public static void main(String[] args) {

    }
}
