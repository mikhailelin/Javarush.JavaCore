package com.javarush.task.task18.task1821;

/* 
Встречаемость символов
*/

public class Solution {
    public static void main(String[] args) {

    }
}
