package com.javarush.task.task18.task1808;

/* 
Разделение файла
*/

public class Solution {
    public static void main(String[] args) {

    }
}
