package com.javarush.task.task18.task1805;

import java.io.FileInputStream;

/* 
Сортировка байт
*/

public class Solution {
    public static void main(String[] args) throws Exception {
    }
}
