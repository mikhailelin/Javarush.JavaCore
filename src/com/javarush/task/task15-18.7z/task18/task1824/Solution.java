package com.javarush.task.task18.task1824;

/* 
Файлы и исключения
*/

public class Solution {
    public static void main(String[] args) {
    }
}
