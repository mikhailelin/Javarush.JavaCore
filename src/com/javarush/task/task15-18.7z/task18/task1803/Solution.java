package com.javarush.task.task18.task1803;

import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;


/* 
Самые частые байты
http://info.javarush.ru/translation/2014/02/11/9-%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D1%8B%D1%85-%D0%B2%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%BE%D0%B2-%D0%BE-Map-%D0%B2-Java.html
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String name = reader.readLine();

        FileInputStream inputStream = new FileInputStream(name);
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		int maxY = 0;
        while ( inputStream.available()>0){
            Integer x = new Integer(inputStream.read());
			if(map.containsKey(x)){
				Integer y = map.get(x)+1;				
				map.put(x,y);
			}else{
				map.put(x,1);
			}
        }
		inputStream.close();

		ArrayList arrY = new ArrayList(map.values());
		maxY = ((Integer)Collections.max(arrY)).intValue();
		
		int max = 0;
		for(Map.Entry<Integer, Integer>  entry: map.entrySet()) {
		  //получить ключ
		  Integer key = entry.getKey();
		  //получить значение
		  Integer value = entry.getValue();
		  if(value.intValue() == maxY){
			  max = key.intValue();
			  System.out.print(max + " ");
		  }
		}

    }
}
