package com.javarush.task.task18.task1810;

/* 
DownloadException
*/

public class Solution {
    public static void main(String[] args) throws DownloadException {

    }

    public static class DownloadException extends Exception {

    }
}
