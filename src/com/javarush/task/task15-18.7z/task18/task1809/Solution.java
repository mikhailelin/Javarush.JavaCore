package com.javarush.task.task18.task1809;

/* 
Реверс файла
*/

public class Solution {
    public static void main(String[] args) {

    }
}
