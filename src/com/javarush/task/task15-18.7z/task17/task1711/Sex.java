package com.javarush.task.task17.task1711;

public enum Sex {
    MALE,
    FEMALE
}
