package com.javarush.task.task17.task1710;

public enum Sex {
    MALE,
    FEMALE
}
