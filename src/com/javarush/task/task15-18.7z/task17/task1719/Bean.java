package com.javarush.task.task17.task1719;

public interface Bean {   //это интерфейс-маркер
}
