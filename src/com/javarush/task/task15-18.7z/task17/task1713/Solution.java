package com.javarush.task.task17.task1713;

import java.util.*;

/* 
Общий список
*/

public class Solution {
    private ArrayList<Long> original = new ArrayList<Long>();

    public static void main(String[] args) {

    }
}
